#!/usr/bin/env python

f=open('fpg_cdbonn24FM.int','r') 
txt=f.readline()
print('Header %s' % txt)
#txt=f.readline()
#print txt

# 1=0f7/2, 2=0f5/2, 3=1p3/2, 4=1p1/2, 5=0g9/2
pnt=[]
#pnt.append(4)
#pnt[1]=3
#pnt[2]=2
#pnt[3]=1
#pnt[4]=5

pnt.append(4)

txt=f.readlines()
#la=

for l in txt:
    try:
        ls=l.split()
        print ls[0:4], ls[4:6],ls[6]
    except:
	print "Error"
f.close()
