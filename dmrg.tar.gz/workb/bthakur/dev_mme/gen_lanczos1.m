n=10;
neig=9;

A(1:n,1:n)=1;

for i=1:n
    A(i,i)=i-1;
    %A(i,i+1)=1;
    %A(i+1,i)=1;
end
for i=1:n
for j=1:n
  if (abs(i-j)==2) 
  A(i,j)=1;
  if (abs(i-j)==1)
  A(i,j)=2;
  end
end 
end
    %A(n,n)=n-1;

    quit
    b(1:n,1:1)=1;
    b=b/norm(b);

    A
    A*b

