#include <mpi.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
    MPI_Init(&argc, &argv);
    int my_rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    int finalize_retcode = MPI_Finalize();
    if(0 == my_rank) fprintf(stderr, "Process, return_code\n");
    fprintf(stderr, "%i, %i\n", my_rank, finalize_retcode);
    return 0;
}
