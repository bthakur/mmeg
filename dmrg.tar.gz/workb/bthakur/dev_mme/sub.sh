#!/bin/bash
#PBS -q admin
#PBS -o job.$PBS_JOBID
#PBS -j oe
#PBS -l nodes=40:ppn=8
#PBS -l walltime=4:30:00
#PBS -V

# echo running at `pwd` on `hostname`

date

#mprun=$HOME/soft/mpich2/bin/mpirun
mprun=/usr/local/packages/mvapich2/1.4/intel-11.1/bin/mpirun_rsh

cd $PBS_O_WORKDIR

$mprun -hostfile $PBS_NODEFILE -np 320 ./a.out

